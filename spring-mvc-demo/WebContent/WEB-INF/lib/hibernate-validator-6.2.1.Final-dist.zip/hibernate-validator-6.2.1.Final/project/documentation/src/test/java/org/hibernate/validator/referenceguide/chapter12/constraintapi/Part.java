package org.hibernate.validator.referenceguide.chapter12.constraintapi;

public class Part {

	private String name;
}
